import React from 'react'

const DoctorDashboard = () => {
  return (
    <div>DoctorDashboard</div>
  )
}

export default DoctorDashboard