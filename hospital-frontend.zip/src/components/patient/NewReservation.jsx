import React from 'react'

const NewReservation = () => {
  return (
    <div>NewReservation</div>
  )
}

export default NewReservation