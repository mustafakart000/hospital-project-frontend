package com.hospital.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;


import com.hospital.dto.ReservationRequest;
import com.hospital.dto.Response.ReservationResponse;
import com.hospital.entity.Reservations;
import com.hospital.mapper.ReservationsMapper;
import com.hospital.repository.ReservationsRepository;

@Service
public class ReservationsService {

    @Autowired
    private ReservationsRepository reservationsRepository;


    public Reservations createReservation(ReservationRequest reservationRequest){
        //o tarih ve saatte randevu var mı kontrolü
        if(reservationsRepository.findByReservationDateAndReservationTime(reservationRequest.getReservationDate(), reservationRequest.getReservationTime()).isPresent()){
            throw new RuntimeException("Bu tarih ve saatte randevu zaten var");
        }
        Reservations reservation = ReservationsMapper.mapToEntity(reservationRequest);
        return reservationsRepository.save(reservation);
    }

    public ReservationResponse getReservationById(Long id){

        Optional<Reservations> reservation = reservationsRepository.findById(id);
        if(reservation.isPresent()){
            return ReservationsMapper.mapToResponse(reservation.get());
        }else{
            throw new RuntimeException("Randevu bulunamadı");
        }
      
    }

   

    public ReservationResponse updateReservation(Long id, ReservationRequest reservationRequest){

        Reservations reservation = reservationsRepository.findById(id).orElseThrow(() -> new RuntimeException("Randevu bulunamadı"));
        Reservations updatedReservation = ReservationsMapper.mapToEntity(reservationRequest, reservation);
        return ReservationsMapper.mapToResponse(reservationsRepository.save(updatedReservation));
    }

    @PreAuthorize("hasAnyRole('DOCTOR', 'PATIENT')")
    public void deleteReservation(Long id){
        if(reservationsRepository.existsById(id)){
            reservationsRepository.deleteById(id);
        }else{
            throw new RuntimeException("Randevu bulunamadı");
        }
    }

    @PreAuthorize("hasAnyRole('DOCTOR', 'PATIENT')")
    public List<ReservationResponse> getAllReservations(){
        return reservationsRepository.findAll().stream().map(ReservationsMapper::mapToResponse).collect(Collectors.toList());
    }
}
