package com.hospital.model;

public enum Role {
    ADMIN,
    DOCTOR,
    PATIENT
} 