import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { Formik, Form } from "formik";
import * as Yup from "yup";

import {
  Form as AntdForm,
  Input,
  Select,
  Button,
  DatePicker,
  Card
} from "antd";
import moment from "moment";
import toast from "react-hot-toast";
import { useNavigate, useParams } from "react-router-dom";

import { ArrowLeftOutlined } from '@ant-design/icons';
import { getDoctorById, updateDoctor } from "../../services/doctor-service";

// DEĞİŞİKLİK YAPILDI: Validation schema alan adları backend ile aynı olacak şekilde düzenlendi.
// Burada phone -> telefon, address -> adres, speciality -> uzmanlik vb.
const validationSchema = Yup.object({
  ad: Yup.string().required("Ad zorunludur"),
  soyad: Yup.string().required("Soyad zorunludur"),
  email: Yup.string()
    .email("Geçerli bir email giriniz")
    .required("Email zorunludur"),
  // telefon alanı numeric kontrol istenirse regex kullanılabilir.
  telefon: Yup.string()
    .matches(/^[0-9]{10,11}$/, "Geçerli bir telefon numarası giriniz")
    .required("Telefon zorunludur"),
  adres: Yup.string().required("Adres zorunludur"),
  birthDate: Yup.date().required("Doğum tarihi zorunludur"),
  kanGrubu: Yup.string().required("Kan grubu zorunludur"),
  tcKimlik: Yup.string().required("TC Kimlik numarası zorunludur"),
  // speciality yerine uzmanlik kullanıyoruz
  uzmanlik: Yup.string().required("Uzmanlık zorunludur"),
  password: Yup.string().required("Şifre zorunludur"),
});

const DoctorEdit = ({ labelCol, wrapperCol }) => {
  const [initialValues, setInitialValues] = useState({
    // DEĞİŞİKLİK YAPILDI: Field isimleri backend ile aynı
    username: "",
    ad: "",
    soyad: "",
    uzmanlik: "", // Başlangıçta boş verebiliriz, ya da default 'NEUROLOGIST' idi
    email: "",
    telefon: "",
    adres: "",
    birthDate: "",
    tcKimlik: "",
    kanGrubu: "",
    diplomaNo: "",
    unvan: "",
    password: ""
  });
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const { id } = useParams();
  
  useEffect(() => {
    const fetchDoctorDetails = async () => {
      try {
        console.log("id", id);
        const response = await getDoctorById(id);
        const doctorData = response;
        console.log("doctorData", doctorData);
        // DEĞİŞİKLİK YAPILDI: Burada backend’den dönen alanlar ile initialValues alanları aynı isimde olmalı.
        setInitialValues({
          ...doctorData,
          birthDate: doctorData.birthDate ? moment(doctorData.birthDate) : null,
        });
        setIsLoading(false);
      } catch (error) {
        toast.error("Doktor bilgileri yüklenemedi");
        console.log("error", error);
        navigate("/dashboard/doctor-management");
      }
    };

    fetchDoctorDetails();
  }, [id, navigate]);

  const handleSubmit = async (values, { setSubmitting, setErrors }) => {
    try {
      // DEĞİŞİKLİK YAPILDI: values içindeki alanlar backend ile aynı isimde zaten.
      const formattedValues = {
        ...values,
        birthDate: values.birthDate ? values.birthDate.format("YYYY-MM-DD") : "",
      };
      console.log("doctor-edit.jsx-values: ", values);
      console.log("doctor-edit.jsx-formattedValues: ", formattedValues);
      const response = await updateDoctor(id, formattedValues);
      console.log("response:  ", response);
      if (response === "OK") {
        toast.success("Doktor bilgileri başarıyla güncellendi");
        navigate("/dashboard/doctor-management");
      }
    } catch (error) {
      setErrors({
        submit: error.response?.data?.message || "Güncelleme işlemi başarısız",
      });
      toast.error("Güncelleme sırasında bir hata oluştu");
    } finally {
      setSubmitting(false);
    }
  };

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <>
      <Button 
        className="position-absolute top-0 end-[-298px] mb-1 bg-gray-200" 
        onClick={() => navigate("/dashboard/doctor-management")}
      >
        <ArrowLeftOutlined />
      </Button>
      <Card
        title="Doktor Bilgileri Düzenleme"
        style={{ maxWidth: 600, margin: "0 auto", borderRadius: "8px" }}
      >
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={(values, actions) => handleSubmit(values, actions)}
          enableReinitialize
          
        >
          {({ values, errors, touched, setFieldValue, isSubmitting, setFieldTouched }) => (
            <Form autoComplete="off">

              
              {/* Ad */}
              <AntdForm.Item
                label="Ad"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.ad && touched.ad ? "error" : ""}
                help={errors.ad && touched.ad ? errors.ad : ""}
              >
                <Input
                  name="ad"
                  placeholder="Ad"
                  onChange={(e) => setFieldValue("ad", e.target.value)}
                  onBlur={() => setFieldTouched("ad", true)}
                  value={values.ad}
                />
              </AntdForm.Item>

              {/* Soyad */}
              <AntdForm.Item
                label="Soyad"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.soyad && touched.soyad ? "error" : ""}
                help={errors.soyad && touched.soyad ? errors.soyad : ""}
              >
                <Input
                  name="soyad"
                  placeholder="Soyad"
                  onChange={(e) => setFieldValue("soyad", e.target.value)}
                  onBlur={() => setFieldTouched("soyad", true)}
                  value={values.soyad}
                />
              </AntdForm.Item>
              
              {/* Diploma No */}
              <AntdForm.Item
                label="Diploma No"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
              >
                <Input 
                  name="diplomaNo" 
                  placeholder="Diploma No" 
                  onChange={(e) => setFieldValue("diplomaNo", e.target.value)}
                  onBlur={() => setFieldTouched("diplomaNo", true)}
                  value={values.diplomaNo} 
                />
              </AntdForm.Item>
              
              {/* Unvan */}
              <AntdForm.Item
                label="Unvan"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
              >
                <Input 
                  name="unvan" 
                  placeholder="Unvan" 
                  onChange={(e) => setFieldValue("unvan", e.target.value)}
                  onBlur={() => setFieldTouched("unvan", true)}
                  value={values.unvan} 
                />
              </AntdForm.Item>
              
              {/* Uzmanlık */}
              <AntdForm.Item
                label="Uzmanlık"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.uzmanlik && touched.uzmanlik ? "error" : ""}
                help={errors.uzmanlik && touched.uzmanlik ? errors.uzmanlik : ""}
              >
                <Select
                  placeholder="Uzmanlık Seçiniz"
                  onChange={(value) => setFieldValue("uzmanlik", value)}
                  onBlur={() => setFieldTouched("uzmanlik", true)}
                  value={values.uzmanlik}
                >
                  <Select.Option value="NEUROLOGIST">NEUROLOGIST</Select.Option>
                  <Select.Option value="CARDIOLOGIST">CARDIOLOGIST</Select.Option>
                  <Select.Option value="DENTIST">DENTIST</Select.Option>
                  <Select.Option value="PEDIATRICIAN">PEDIATRICIAN</Select.Option>
                  <Select.Option value="GYNECOLOGIST">GYNECOLOGIST</Select.Option>
                </Select>
              </AntdForm.Item>

              {/* TC Kimlik */}
              <AntdForm.Item
                label="TC Kimlik"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.tcKimlik && touched.tcKimlik ? "error" : ""}
                help={errors.tcKimlik && touched.tcKimlik ? errors.tcKimlik : ""}
              >
                <Input 
                  name="tcKimlik" 
                  placeholder="TC Kimlik" 
                  onChange={(e) => setFieldValue("tcKimlik", e.target.value)} 
                  onBlur={() => setFieldTouched("tcKimlik", true)}
                  value={values.tcKimlik} 
                />
              </AntdForm.Item>

              {/* Email */}
              <AntdForm.Item
                label="Email"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.email && touched.email ? "error" : ""}
                help={errors.email && touched.email ? errors.email : ""}
              >
                <Input
                  name="email"
                  placeholder="Email"
                  onChange={(e) => setFieldValue("email", e.target.value)}
                  onBlur={() => setFieldTouched("email", true)}
                  value={values.email}
                />
              </AntdForm.Item>

              {/* Telefon */}
              <AntdForm.Item
                label="Telefon"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.telefon && touched.telefon ? "error" : ""}
                help={errors.telefon && touched.telefon ? errors.telefon : ""}
              >
                <Input
                  name="telefon"
                  placeholder="Telefon"
                  onChange={(e) => setFieldValue("telefon", e.target.value)}
                  onBlur={() => setFieldTouched("telefon", true)}
                  value={values.telefon}
                />
              </AntdForm.Item>

              {/* Doğum Tarihi */}
              <AntdForm.Item
                label="Doğum Tarihi"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.birthDate && touched.birthDate ? "error" : ""}
                help={errors.birthDate && touched.birthDate ? errors.birthDate : ""}
              >
                <DatePicker
                  style={{ width: "100%" }}
                  placeholder="Doğum Tarihi"
                  onChange={(date) => setFieldValue("birthDate", date)}
                  onBlur={() => setFieldTouched("birthDate", true)}
                  value={values.birthDate}
                />
              </AntdForm.Item>

              {/* Adres */}
              <AntdForm.Item
                label="Adres"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.adres && touched.adres ? "error" : ""}
                help={errors.adres && touched.adres ? errors.adres : ""}
                
              >
                <Input.TextArea
                  name="adres"
                  placeholder="Adres"
                  rows={3}
                  onChange={(e) => setFieldValue("adres", e.target.value)}
                  onBlur={() => setFieldTouched("adres", true)}
                  value={values.adres}
                  autoComplete="off"
                />
              </AntdForm.Item>

              {/* Kan Grubu */}
              <AntdForm.Item
                label="Kan Grubu"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.kanGrubu && touched.kanGrubu ? "error" : ""}
                help={errors.kanGrubu && touched.kanGrubu ? errors.kanGrubu : ""}
              >
                <Select
                  placeholder="Kan Grubu Seçiniz"
                  onChange={(value) => setFieldValue("kanGrubu", value)}
                  onBlur={() => setFieldTouched("kanGrubu", true)}
                  value={values.kanGrubu}
                >
                  <Select.Option value="A+">A+</Select.Option>
                  <Select.Option value="A-">A-</Select.Option>
                  <Select.Option value="B+">B+</Select.Option>
                  <Select.Option value="B-">B-</Select.Option>
                  <Select.Option value="AB+">AB+</Select.Option>
                  <Select.Option value="AB-">AB-</Select.Option>
                  <Select.Option value="0+">0+</Select.Option>
                  <Select.Option value="0-">0-</Select.Option>
                </Select>
              </AntdForm.Item>

              {/* Şifre */}
              <AntdForm.Item
                label="Şifre"
                labelCol={labelCol}
                wrapperCol={wrapperCol}
                validateStatus={errors.password && touched.password ? "error" : ""}
                help={errors.password && touched.password ? errors.password : ""}
              >
                <Input.Password 
                  name="password" 
                  placeholder="Şifre" 
                  onChange={(e) => setFieldValue("password", e.target.value)}
                  onBlur={() => setFieldTouched("password", true)}
                  value={values.password}
                />
              </AntdForm.Item>

              {errors.submit && (
                <div style={{ color: "red", marginBottom: "16px" }}>
                  {errors.submit}
                </div>
              )}

              <Button
                type="primary"
                htmlType="submit"
                block
                loading={isSubmitting}
                disabled={isSubmitting}
              >
                Güncelle
              </Button>
            </Form>
          )}
        </Formik>
      </Card>
    </>
  );
};

DoctorEdit.propTypes = {
  labelCol: PropTypes.object,
  wrapperCol: PropTypes.object,
};

export default DoctorEdit;
