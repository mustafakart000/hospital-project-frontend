import React from 'react';
import DoctorRegistration from '../../components/doctor/DoctorRegistration';
import { setOperation } from '../../redux/slices/misc-slice';
import { useDispatch, useSelector } from 'react-redux';
import {  Tabs } from 'antd';
import DoctorTable from '../../components/doctor/doctors-table';
import { useLocation } from 'react-router-dom';
import { UnorderedListOutlined, UserAddOutlined } from '@ant-design/icons';


const DoctorManagement = () => {
  const location = useLocation();
  console.log("location", location);

  const { currentOperation } = useSelector(state => state.misc);
  const dispatch = useDispatch();
  


  // Tabs items configuration
  const items = [
    {
      key: 'new',
      label: 'Doktor Oluştur',
      children: <DoctorRegistration labelCol={{ span: 8 }} wrapperCol={{ span: 16 }} />, // Pass props here
      icon:<UserAddOutlined style={{ fontSize: '18px' }} />,
      
    },
    {
      key: 'list',
      label: 'Doktorlar Listesi',
      children: <DoctorTable />, // Simplified as it doesn't require additional props
      icon:<UnorderedListOutlined style={{ fontSize: '18px' }} />
    },
  ];

  return (
    <Tabs 
      activeKey={currentOperation} 
      onChange={(key) => dispatch(setOperation(key))} 
      items={items} 
      tabBarGutter={25}
      centered
            
    />
  );
};

export default DoctorManagement;
