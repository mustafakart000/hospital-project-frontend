import React from 'react'
import DoctorPanel from '../../components/doctor/DoctorPanel'

const DoctorDashboard = () => {
  return (
    <div><DoctorPanel/></div>
  )
}

export default DoctorDashboard