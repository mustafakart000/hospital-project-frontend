import React from 'react'
import AdminManagement from '../../components/admin/admin-management'


const AdminDashboardPage = () => {


  return (
    <>
      <AdminManagement />
    </>
  )
}

export default AdminDashboardPage