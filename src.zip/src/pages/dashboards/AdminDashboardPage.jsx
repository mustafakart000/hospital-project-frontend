import React from 'react'


const AdminDashboardPage = () => {


  return (
    <>
      
    </>
  )
}

export default AdminDashboardPage