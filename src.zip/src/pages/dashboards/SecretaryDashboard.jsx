import React from 'react'

const SecretaryDashboard = () => {
  return (
    <div>SecretaryDashboard</div>
  )
}

export default SecretaryDashboard